Welcome to the thing that can make you some money, below are the steps to get started!


Proxy Setup: 


- Head over to this link (https://cbf.world/proxies)
- Sign up
- once signed up and confirmed your email BUY DATACENTER PROXIES
- I would recommend buying 50gb depending on how many searches you decide to do
- Once purchased click on Datacenter (pay/gb) -> delete the Authentication method account it gives you -> make a new one
- Once it's made scroll down to endpoint generator and plug in that username and password you just made from the previous step
- keep proxy location to US
- Change to rotating proxies and HTTP
- Generate about 6000 endpoints (just in case)
- Paste proxies into proxies.txt

Using the Scraper:

- Simply open Walmart Checker.exe
- Paste in the sku
- and watch the magic happen!

Using the price checker:

- Open Price Checker.exe
- put in the msrp (Enter the dollar amount of the item. Ex: 5. This will autom calculate everything for you.)
- Put in the sku 
- this will out put a text file with the sorted prices

FAQ:

Q: I'm getting an error while scraping (Exception while scraping (storeID): HTTPSConnectionPool(host='www.walmart.com', port=443): Max retries exceeded with url: /ip/(sku)?wl13=(storeID) (Caused by ProxyError('Unable to connect to proxy', OSError('Tunnel connection failed: 503 Service Unavailable'))) 

A: This normally means your proxies are acting up (yes it's normal), just wait it out. Go outside, play some video games, go source some products to scrape

Q: The app just crashes right away when I open it

A: This means your dumbass moved the exe out of the folder, it needs the store_id.txt & proxies.txt files

Q: I'm not finding anything, can I have a refund.

A: No, go away. NO REFUNDS. I've spent a lot of time on this script, and it does work.



Other things:

I will update the exe as time goes, and if this current trick gets patched and another way comes out I will update the exe to what it needs for you to make some money! 

I'm still working on ways to make this A LOT faster, just give me time and once it's done you will get the updated exe :)

If you put your proxies in right after you purchase they may not work, give it 10 - 20 minutes and try again!

You will see the occasional "Server disconnected" this is normal, work is being done to get this resolved!

This also will now include shipping info! In the output.txt file it'll be in this format: "$5.72 - 5725 - Not available: https://www.walmart.com/ip/1142918355?wl13=5725" Not available being the shipping info of that product!